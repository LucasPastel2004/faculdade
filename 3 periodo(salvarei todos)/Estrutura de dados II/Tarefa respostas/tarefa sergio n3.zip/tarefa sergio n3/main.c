#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TABLE_SIZE 1303

typedef struct ListaN{
    char *NomeP;
    int pos;
    struct ListaN *prox;

}Nome;

Nome *TabelaHash[TABLE_SIZE];

int FunçãoHash(char *NomeP){
    int valor = 7;
    int tam = strlen(NomeP);
    for(int i = 0; i < tam; i++){
        valor = 31 * valor + (int) NomeP[i];
    }
    return (valor % TABLE_SIZE) & TABLE_SIZE;
}

void iniciaHash(){
    for(int i = 0; i < TABLE_SIZE; i++){
        TabelaHash[i] = NULL;
    }
}
void insere(char *NomeP, int pos){
    int index = FunçãoHash(NomeP);
    Nome *nome = malloc(sizeof(Nome));
    nome->NomeP = strdup(NomeP);
    nome->pos = pos;
    nome->prox = TabelaHash[index];
    TabelaHash[index] = nome;
}
void liberaHash(){
    for(int i =0; i < TABLE_SIZE; i++){
        Nome *nome = TabelaHash[i];
        while(nome != NULL){
            Nome *temporario = nome;
            nome = nome->prox;
            free(temporario->NomeP);
            free(temporario);
        }
    }
}
void lerArquivo(const char *Arquivo){

    char i = 0;
    FILE *arquivo;
    arquivo = fopen("C:\\Users\\Cliente\\CLionProjects\\tarefa sergio n3\\nomes.txt","r");
    if(arquivo == NULL){
        perror("Nao foi possivel abrir o arquivo");
        return;
    }
    char buffer[256];
    int pos = 0;
    while(fgets(buffer,sizeof(buffer), arquivo)){
        buffer[strcspn(buffer, "\n")] = 0;
        insere(buffer, pos++);
    }
    fclose(arquivo);

}
void imprimirDados(){
    printf(" A lista sera impressa neste formato -> (Indice, Nome)\n");
    for (int i = 0; i < TABLE_SIZE; i++){
        Nome *nome = TabelaHash[i];
        while(nome != NULL){
            printf("(%d, %s)\n", nome->pos+1, nome->NomeP);
            nome = nome->prox;
        }
    }

}

int main() {
    iniciaHash();
    lerArquivo(".\\nomes.txt");
    imprimirDados();
    liberaHash();
    return 0;
}

