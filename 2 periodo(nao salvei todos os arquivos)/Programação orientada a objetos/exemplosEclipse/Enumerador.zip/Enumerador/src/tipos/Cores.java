package tipos;






public enum Cores {
	VERMELHO,
	AZUL,
	AMARELO,
	VERDE,
	BRANCO,
	PRETO

}
