package tipos;

public enum UnidadesFederacao {
	GO,
	DF,
	SP,
	RJ,
	MG,
	ETC
}
