package tipos;

public enum EstadoMatriculaAluno {
	TRANCADO,
	MATRICULADO,
	EGRESSO
}
