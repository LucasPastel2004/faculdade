package principal;

import alimentos.Fruta;
import serializacao.Deserializador;
import serializacao.Serializador;

public class Principal {
    public static void main(String args[]){
       //serializa
		
		
		  Serializador s = new Serializador(); Fruta fruta = new
		  Fruta("Maca","Vermelha"); try { s.serializar("./fruta.obj", fruta); } catch
		  (Exception ex){ System.err.println("Falha ao serializar! - " +
		  ex.toString()); }
		 		  
		 
        //deserializa        
        Deserializador d = new Deserializador();
        fruta = null;
        try {
            fruta = (Fruta) d.deserializar("./fruta.obj");
        } catch (Exception ex) {
            System.err.println("Falha ao deserializar! - " + ex.toString());
        }
        System.out.println(fruta.getNome() + " - " + fruta.getCor());
    }    
}