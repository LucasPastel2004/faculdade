package drh;

public class Reitor extends EmpregadoDaFaculdade {
	  // informa��es extras
    public String getInfo() {
        return super.toString() + " e ele � um reitor";
    }
     // n�o sobrescrevemos o getGastos!!!

}
