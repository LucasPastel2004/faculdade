package nodo;

public class Nodo {
	
	private Nodo nodoProx;
	private Object conteudo;

	
	
	public Nodo(Nodo nodoProx, Object conteudo) {
		this.nodoProx = nodoProx;
		this.conteudo = conteudo;
	}

	public Nodo getNodoProx() {
		return nodoProx;
	}

	public void setNodoProx(Nodo nodoProx) {
		this.nodoProx = nodoProx;
	}

	public Object getConteudo() {
		return conteudo;
	}

	public void setConteudo(Object conteudo) {
		this.conteudo = conteudo;
	}
}