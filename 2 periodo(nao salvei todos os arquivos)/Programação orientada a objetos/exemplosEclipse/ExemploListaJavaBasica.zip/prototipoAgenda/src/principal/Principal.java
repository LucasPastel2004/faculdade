package principal;

import contato.Contato;
import lista.Lista;

class Principal
{
	public static void main(String args[])
	{
		Lista livroAmigos = new Lista();
	
		Contato am1 = new Contato("Alexandre","Rua: 01");
		
		Contato am2 = new Contato("Jo�o","Rua 12");
		
		Contato am3 = new Contato("Jos�","Rua 99");
		
		//System.out.println(am1.getEndereco() + am1.getNome());
		
		livroAmigos.insere(am1);
		livroAmigos.insere(am2);
		livroAmigos.insere(am3);
		
		livroAmigos.imprimirLista();
	
		//Somente para testar o achaUltimo da lista
		Object objetoAux = livroAmigos.achaUltimo().getConteudo();
		if( objetoAux instanceof Contato){
			Contato aux = (Contato)objetoAux;
			System.out.println("Ultimo da lista " + aux.toString());
		}
	}
}