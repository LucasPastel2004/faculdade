package lista;

import contato.Contato;
import nodo.Nodo;

public class Lista
{
	
	
	
	Nodo cabeca = null;
	
	public Lista()
	{
		this.cabeca = null;
	}
	
	public void insere(Object item)
	{
		Nodo temp = new Nodo(null, item);
		
		if(this.cabeca == null)
		{
			this.cabeca = temp;
			temp.setNodoProx(null);
		}	
		else
		{
			Nodo ultimo = achaUltimo();
			
			ultimo.setNodoProx(temp);
			temp.setNodoProx(null);
				
		}
	}
	
	public Nodo achaUltimo()
	{
		Nodo aux = this.cabeca;
		do
		{
			if(aux.getNodoProx() != null)
				aux = aux.getNodoProx();
								
		}while(aux.getNodoProx() != null);
		
		return (aux);
	}
	
	public void imprimirLista()
	{
		Nodo aux = this.cabeca;
		do
		{
			if(aux.getConteudo() instanceof Contato){
				Contato auxContato = (Contato)aux.getConteudo();
				System.out.println(auxContato.toString());
			}
			//Aqui teste para cada um dos poss�veis tipos de dados inseridos dentro da lista
			//Normalmente lista s�o homog�neas e n�o precisa ficar testando.
			//Obviamente por motivos organiza��o do c�digo.
			aux = aux.getNodoProx();
		}while(aux != null);
	}
}