package exemplo.composicao;

class Livro
{
 

	
	
	
	
	public String titulo;
    public String autor;
     
    Livro(String titulo, String autor)
    {
         
        this.titulo = titulo;
        this.autor = autor;
    }
}