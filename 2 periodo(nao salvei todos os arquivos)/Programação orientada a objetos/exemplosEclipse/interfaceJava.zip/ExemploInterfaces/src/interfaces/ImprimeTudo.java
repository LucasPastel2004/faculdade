	package interfaces;

public interface ImprimeTudo {
	void imprimir(String texto);
	void pararImpressao();
	void pausarImpressao();
}
