package interfaces;



public class ImpressoraConsole implements ImprimeTudo, novaInterface {

	@Override
	public void imprimir(String txt) {
		System.out.println(txt);

	}
	public void pararImpressao()
	{
		
	}
	
	public void voceDeveMeImplementar() {
		
	}
	
	public void pausarImpressao() {
		//Fazer o que deve ser feito: código de pausar a impressao
	}
}
