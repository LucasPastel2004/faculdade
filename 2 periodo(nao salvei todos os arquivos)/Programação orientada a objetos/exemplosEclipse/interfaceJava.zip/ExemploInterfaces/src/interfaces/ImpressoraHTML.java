package interfaces;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class ImpressoraHTML implements ImprimeTudo {

	
	
	
	
	@Override
	public void imprimir(String texto) {
		// TODO Auto-generated method stub
		File arquivo = new File("./impressao.htm");
		//vamos escrever no arquivo
		FileWriter fw = null;
		BufferedWriter bw = null;
		
		try {
			arquivo.createNewFile();
			//vamos escrever no arquivo
			fw = new FileWriter(arquivo);
			bw = new BufferedWriter(fw);

			String html = "<h2>Ol&aacute;. Sou um texto HTML! Abaixo voc&ecirc; ter&aacute; "
					+ "o texto injetado da linguagem Java.</h2>\r\n" + 
					"<p><strong>Texto vindo do java:</strong></p><span style=\"color: #ff0000;\">"+texto+"</span><br /></strong></p>";
			bw.write(html);
			bw.newLine();
		}catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			try {
				if(bw != null)
					bw.close();
				if(fw != null)
					fw.close();	
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
