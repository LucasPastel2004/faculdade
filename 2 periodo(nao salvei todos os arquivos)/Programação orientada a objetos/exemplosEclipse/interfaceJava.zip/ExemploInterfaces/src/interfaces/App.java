package interfaces;

public class App {

	
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ImpressoraConsole printer = new ImpressoraConsole();
		printer.imprimir("Alo Mundo. Meu teste de Interface implementado!!!");
		
		//Agora vamos imprimir um texto em um HTML
		ImpressoraHTML printerHTML = new ImpressoraHTML();
		printerHTML.imprimir("Eclipse é fera!!!");
	}

}
