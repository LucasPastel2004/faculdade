package interfaces;

public interface novaInterface {
	public void voceDeveMeImplementar();

}
