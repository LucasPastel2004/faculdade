/**
 * 
 */
/**
 * 
 */
module ExemploInterfaces {
}