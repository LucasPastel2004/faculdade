package principal;

import enquete.controller.TelaVotacaoController;
import enquete.model.EnqueteSimples;
import enquete.view.TelaResultado;
import enquete.view.TelaResultadoPercentual;
import enquete.view.TelaVotacao;

public class Enquete{

    public static void main(String[] args) {

        // Modelo
        EnqueteSimples enquete= new EnqueteSimples();


        // Controlador da Interface "TelaVotacao"
        TelaVotacaoController ctrl = new TelaVotacaoController(enquete);

        // Interface que altera o estado do modelo
        TelaVotacao votacao = new TelaVotacao(ctrl);
        votacao.setLocation(5,5);
        
        // Interface que exibe o resultado absoluto da votacao
        TelaResultado resultado = new TelaResultado(votacao);
        resultado.setLocation(120,5);

        // Interface que exibe o resultado percentual da votacao
        TelaResultadoPercentual resultadoPerc = new TelaResultadoPercentual(votacao);
        resultadoPerc.setLocation(250,5);
        
        // Adicionando as interfaces interessadas na mudan�a do
        // estado do modelo
        enquete.addEnqueteListener(votacao);
        enquete.addEnqueteListener(resultado);
        enquete.addEnqueteListener(resultadoPerc);

        // Povoando o modelo
        enquete.addOpcao("Azul");
        enquete.addOpcao("Vermelho");
        //enquete.addOpcao("Opçao 3");
        //enquete.addOpcao("Opçao 4");
        //enquete.addOpcao("Meu Candidato Preferido!");


        // Exibindo as interfaces
        votacao.show();
        resultado.show();
        resultadoPerc.show();
    }

}