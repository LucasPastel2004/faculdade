package enquete.model;

import java.util.EventListener;

public interface EnqueteListener extends EventListener {


    /**
     * Invocado quando um novo voto � contabilizado na Enquete.
     * @param event Evento gerado pela Enquete.
     */
    public void novoVoto(EnqueteEvent event);
    
    /**
     * Invocado quando uma nova op��o � adicionada � Enquete.
     * @param event Evento gerado pela Enquete.
     */
    public void novaOpcao(EnqueteEvent event);
}