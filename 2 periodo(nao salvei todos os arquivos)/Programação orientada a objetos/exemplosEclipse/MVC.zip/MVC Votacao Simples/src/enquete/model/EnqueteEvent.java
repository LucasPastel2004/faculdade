package enquete.model;

import java.util.EventObject;

public class EnqueteEvent extends EventObject {
    
    private String opcao = null;
    private int votos = 0;
    
    public EnqueteEvent(EnqueteSimples source){
        super(source);
    }
    public EnqueteEvent(EnqueteSimples source,String opcao){
        this(source);
        this.opcao = opcao;
    }

    /**
     * Retorna a op��o associada ao evento gerado.
     * A op��o pode ser uma nova op��o adicionada � EnqueteSimples
     * ou a op��o escolhida para adicionar um novo voto.
     * @return String op��o
     */
    public String getOpcao() {
        return opcao;
    }

    /**
     * Retorna o numero de votos da opcao
     * @return int votos
     */
    public int getVotos() {
        return ((EnqueteSimples)this.source).getVotos(opcao);
    }
    
    /**
     * Retorna o total de votos da enquete
     * @return int
     */
    public int getTotalVotos() {
        return ((EnqueteSimples)this.source).getTotalVotos();
    }

}