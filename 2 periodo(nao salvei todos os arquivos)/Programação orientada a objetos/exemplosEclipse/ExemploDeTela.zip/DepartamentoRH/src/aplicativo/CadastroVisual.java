package aplicativo;
import colaboradores.Pessoa;
import itensVisuais.MeuFrame;

public class CadastroVisual {
	public static void main(String[] args)	throws Exception
	{
		MeuFrame f = new MeuFrame();
		
		
	}

}
