#include "Ponto.h" //inclui os Prot�tipos
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

// Defini�o do tipo de dados
struct ponto {
  float x;
  float y;
};

// Cria um vetor de pontos do tipo *Ponto

Ponto **vecpontos;    // vetor de armazenamento dos ponteiros dos pontos
int pontos_inseridos; // quantidade pontos inseridos ate o momento

// inicializa o vetor de pontos, alocando a memoria
void cria_vetor_pontos(int tamanho) {
  pontos_inseridos = 0;
  vecpontos = (Ponto **)malloc(sizeof(Ponto *) * tamanho);
  if (vecpontos == 0) {
    exit(1);
  }
}

// cria um ponto com os valores "x" e "y",
// insere esse ponto no vetor de pontos
// vecpontos, e incrementa a quantidade
// de pontos inseridos

void pto_insere(float x, float y) {
  Ponto *p = (Ponto *)malloc(sizeof(Ponto));
  if (p == NULL)
    exit(1);
  p->x = x;
  p->y = y;
  vecpontos[pontos_inseridos] = p;
  pontos_inseridos++;
}

// Libera toda a memoria alocada
void libera_vetor_pontos() {
  for (int i = 0; i < pontos_inseridos; i++) {
    free(vecpontos[i]);
  }
  free(vecpontos);
}

// imprime o ponto medio da lista de pontos
void imprime_media() {

  float mediax = 0;
  float mediay = 0;
  for (int i = 0; i < pontos_inseridos; i++) {
    mediax = mediax + vecpontos[i]->x;
    mediay = mediay + vecpontos[i]->y;
  }
  mediax = mediax / (float)pontos_inseridos;
  mediay = mediay / (float)pontos_inseridos;

  printf("ponto medio: (%f, %f)\n", mediax, mediay);
}
void pto_remove(float posicao_ponto) {
  // Verifica se a posição está dentro dos limites válidos
  if (posicao_ponto < 0 || posicao_ponto >= pontos_inseridos) {
    printf("Posicao invalida.\n");
    return; // Sai da função se a posição for inválida
  }

  // Libera a memória do ponto na posição especificada
  free(vecpontos[(int)posicao_ponto]);

  // Move os pontos posteriores para preencher o espaço vazio
  for (int i = posicao_ponto; i < pontos_inseridos - 1; i++) {
    vecpontos[i] = vecpontos[i + 1];
  }

  // Atualiza a quantidade de pontos inseridos
  pontos_inseridos--;
}
