// Arquivo Ponto.h
typedef struct ponto Ponto;

// Cria um vetor de pontos
void cria_vetor_pontos(int tamanho);

// insere os valores "x" e "y" de um ponto na lista
void pto_insere(float x, float y);

// remove o ponto na posicao posicao_ponto
void pto_remove(float posicao_ponto);

// Libera todos os pontos do vetor
void libera_vetor_pontos();

// Calcula e imprime o ponto medio
void imprime_media();

void pto_remove(float posicao_ponto);
