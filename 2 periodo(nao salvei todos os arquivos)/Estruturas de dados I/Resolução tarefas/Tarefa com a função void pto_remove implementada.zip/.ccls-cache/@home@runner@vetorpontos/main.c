#include <stdio.h>
#include <stdlib.h>
#include "Ponto.h"
int main(){
    printf("criando vetor de 4 posicoes\n");
    
    cria_vetor_pontos(4);
    
    printf("inserindo 4 pontos\n");    
    pto_insere(1,2);
    pto_insere(2,4);
    pto_insere(3,6);
    pto_insere(4,8);
    

    //imprime o ponto médio
    imprime_media();
    
    libera_vetor_pontos();

    return 0;
}
